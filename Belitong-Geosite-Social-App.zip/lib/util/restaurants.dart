List restaurants = [
  {
    "img": "assets/geo-1.jpg",
    "title": "Laskar Pelangi",
    "address": "Jl. Laskar Pelangi, Lenggang, Kec. Gantung",
    "rating": "4.5"
  },
  {
    "img": "assets/geo-2.jpg",
    "title": "Nam Salu Open Pit",
    "address": "Desa Senyubuk. Kabupaten Belitung Timur",
    "rating": "4.0"
  },
  {
    "img": "assets/geo-4.jpg",
    "title": "Terong Tourism Village",
    "address": "Kelurahan Terong, Kabupaten Belitung",
    "rating": "4.5"
  },
  {
    "img": "assets/geo-5.jpg",
    "title": "Kuale Granite Mangrove ",
    "address": "Desa Kuale Sijuk, Kabupaten Belitung",
    "rating": "4.5"
  },
  {
    "img": "assets/geo-6.jpg",
  },
  {
    "img": "assets/geo-7.jpg",
  },
  {
    "img": "assets/geo-8.jpg",
  },
  {
    "img": "assets/geo-9.jpg",
  },
  {
    "img": "assets/geo-8.jpg",
  }
];
