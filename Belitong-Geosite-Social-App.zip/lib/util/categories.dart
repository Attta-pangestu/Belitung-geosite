import 'package:flutter/material.dart';

List categories = [
  {
    "name": "Budaya",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/geo-1.jpg"
  },
  {
    "name": "Tambang",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/geo-2.jpg"
  },
  {
    "name": "Mangrove",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/geo-3.jpg"
  },
  {
    "name": "Pantai",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/geo-7.jpg"
  },
  {
    "name": "Hutan",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/geo-9.jpg"
  },
];
