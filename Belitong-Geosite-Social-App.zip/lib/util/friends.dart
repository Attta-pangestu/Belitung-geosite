List friends = [
  "assets/cm-1.jpg",
  "assets/cm-2.jpg",
  "assets/cm-3.jpg",
  "assets/cm-4.jpg",
  "assets/cm-1.jpg",
  "assets/cm-1.jpg",
  "assets/cm-2.jpg",
  "assets/cm-3.jpg",
  "assets/cm-1.jpg"
];
